import React from 'react';

export default () =>
  <span style={{ fontWeight: 700 }}>🔥 Top Product </span>;
